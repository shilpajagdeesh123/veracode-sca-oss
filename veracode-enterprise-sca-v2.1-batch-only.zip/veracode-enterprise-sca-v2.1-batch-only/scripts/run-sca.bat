@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
set "ENVFILE=%ROOT%\config\veracode-sca.env"

if "%~1"=="" goto :usage
set "TARGET=%~f1"
if not exist "%TARGET%" (
  echo [ERROR] Project path does not exist: %TARGET%
  exit /b 2
)

rem Load KEY=VALUE configuration without PowerShell.
if exist "%ENVFILE%" (
  for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%ENVFILE%") do (
    if not "%%~A"=="" if not "%%~B"=="" set "%%~A=%%~B"
  )
)

if not "%~2"=="" set "VERACODE_APP_NAME=%~2"
if not defined SRCCLR_REGION set "SRCCLR_REGION=COM"

if not defined VERACODE_API_KEY_ID (
  echo [ERROR] VERACODE_API_KEY_ID is not configured.
  goto :confighelp
)
if not defined VERACODE_API_KEY_SECRET (
  echo [ERROR] VERACODE_API_KEY_SECRET is not configured.
  goto :confighelp
)
if not defined VERACODE_APP_NAME (
  echo [ERROR] VERACODE_APP_NAME is required for an HMAC application-profile SCA scan.
  goto :confighelp
)

where srcclr >nul 2>nul
if errorlevel 1 (
  echo [ERROR] srcclr was not found on PATH.
  echo.
  echo This Windows package intentionally does NOT execute PowerShell, so it works
  echo on machines where unsigned .ps1 files are blocked by AllSigned policy.
  echo Install the Veracode SCA CLI using an IT-approved/signed installation method,
  echo then make sure srcclr.exe is on PATH and rerun this BAT file.
  echo.
  echo Verify after installation with: srcclr test
  exit /b 3
)

where java >nul 2>nul
if errorlevel 1 echo [WARN] Java was not found on PATH. Java projects may fail to scan.
where mvn >nul 2>nul
if errorlevel 1 echo [WARN] Maven was not found on PATH. Maven projects may fail to resolve dependencies.

for %%I in ("%TARGET%") do set "PROJECT=%%~nxI"
for /f %%I in ('wmic os get localdatetime ^| find "." 2^>nul') do set "DT=%%I"
if defined DT (
  set "STAMP=!DT:~0,8!_!DT:~8,6!"
) else (
  set "STAMP=run"
)
set "OUT=%ROOT%\.github\output\%PROJECT%\%STAMP%"
if not exist "%OUT%" mkdir "%OUT%" >nul 2>nul
set "JSON=%OUT%\sca-results.json"
set "LOG=%OUT%\sca-console.log"
set "TESTLOG=%OUT%\srcclr-test.log"

if exist "%TARGET%\pom.xml" (
  where mvn >nul 2>nul
  if not errorlevel 1 (
    echo [INFO] Capturing Maven dependency tree...
    pushd "%TARGET%"
    call mvn dependency:tree > "%OUT%\dependency-tree.txt" 2>&1
    set "MAVEN_RC=!ERRORLEVEL!"
    popd
    if not "!MAVEN_RC!"=="0" echo [WARN] mvn dependency:tree returned !MAVEN_RC!. SCA scan will still be attempted.
  )
)

echo ============================================================
echo Veracode Enterprise SCA - HMAC / BAT-only
echo ============================================================
echo Target      : %TARGET%
echo Application : %VERACODE_APP_NAME%
echo Region      : %SRCCLR_REGION%
echo Output      : %OUT%
echo PowerShell  : NOT USED
echo ============================================================

echo [INFO] Testing SCA CLI...
call srcclr test > "%TESTLOG%" 2>&1
if errorlevel 1 (
  echo [ERROR] srcclr test failed. See: %TESTLOG%
  exit /b 4
)

echo [INFO] Starting full SCA scan for direct and transitive dependencies...
call srcclr scan "%TARGET%" --appname="%VERACODE_APP_NAME%" --update-advisor --json="%JSON%" --show-cli > "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
type "%LOG%"
if not "%RC%"=="0" (
  echo.
  echo [ERROR] Veracode SCA scan failed with exit code %RC%.
  echo Log: %LOG%
  exit /b %RC%
)

echo.
echo [SUCCESS] SCA scan completed.
echo JSON : %JSON%
echo Log  : %LOG%
if exist "%OUT%\dependency-tree.txt" echo Maven dependency tree: %OUT%\dependency-tree.txt
exit /b 0

:usage
echo Usage:
echo   run-veracode-sca.bat ^<project-path^> [Veracode-App-Name]
echo.
echo Example:
echo   run-veracode-sca.bat C:\work\customer-service customer-service
exit /b 2

:confighelp
echo Configure HMAC credentials in:
echo   %ENVFILE%
echo or set them as environment variables.
exit /b 2

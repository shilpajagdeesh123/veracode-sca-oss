@echo off
setlocal EnableExtensions
call "%~dp0scripts\run-sca.bat" %*
exit /b %ERRORLEVEL%

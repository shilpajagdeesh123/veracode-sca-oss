# Execution Guide

1. Extract the package.
2. Install Veracode SCA CLI through your organization's approved Windows software channel and ensure `srcclr.exe` is on PATH.
3. Run `srcclr test` from CMD.
4. Copy `config\veracode-sca.env.example` to `config\veracode-sca.env`.
5. Enter HMAC API ID, HMAC secret, and existing Veracode application profile name.
6. Open CMD (PowerShell is not required).
7. Run `run-veracode-sca.bat C:\path\to\project "Application Profile Name"`.
8. The launcher validates configuration and `srcclr`, optionally captures `mvn dependency:tree`, then executes a full `srcclr scan` with `--appname`, `--update-advisor`, JSON output, and CLI output.
9. Review `.github\output\<project>\<timestamp>\` and the linked application profile in Veracode.

For transitive dependency analysis, use the normal full scan; do not add `--quick`.

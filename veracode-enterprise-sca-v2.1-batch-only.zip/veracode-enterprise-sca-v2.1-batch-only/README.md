# Veracode Enterprise SCA v2.1 - HMAC / Windows BAT-only

Purpose: run Veracode SCA Agent-Based Scan with HMAC credentials and an application profile without executing any local PowerShell script. This avoids the `run-sca.ps1 is not digitally signed` failure on Windows environments enforcing AllSigned.

## Windows prerequisites
- Veracode SCA CLI (`srcclr.exe`) installed using an organization-approved/signed method and available on PATH.
- HMAC API credentials.
- Existing Veracode application profile suitable for `--appname` linking.
- Native build tools required by the project (for example Java/Maven for Maven projects).

## Configure
1. Copy `config\veracode-sca.env.example` to `config\veracode-sca.env`.
2. Set `VERACODE_API_KEY_ID`, `VERACODE_API_KEY_SECRET`, and `VERACODE_APP_NAME`.
3. Do not commit `veracode-sca.env`.

## Run
`run-veracode-sca.bat C:\work\customer-service customer-service`

The launcher uses only CMD/BAT. It does not call `powershell.exe`, does not use `-ExecutionPolicy Bypass`, and does not require an unsigned `.ps1` file.

## Outputs
`.github\output\<project>\<timestamp>\`
- `sca-results.json`
- `sca-console.log`
- `srcclr-test.log`
- `dependency-tree.txt` for Maven projects when Maven is available

## Important installation note
This package deliberately does not auto-run Veracode's Windows `ci.ps1` bootstrap, because an enterprise AllSigned policy can block unsigned PowerShell scripts. If `srcclr` is missing, the BAT exits with installation guidance instead of weakening or bypassing execution policy.

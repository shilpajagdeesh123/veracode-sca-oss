#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="${1:-.}"
APP_ARG="${2:-}"
ENV_FILE="$ROOT/config/veracode-sca.env"
if [ -f "$ENV_FILE" ]; then set -a; . "$ENV_FILE"; set +a; fi
[ -n "$APP_ARG" ] && VERACODE_APP_NAME="$APP_ARG"
: "${VERACODE_API_KEY_ID:?HMAC credential VERACODE_API_KEY_ID is required}"
: "${VERACODE_API_KEY_SECRET:?HMAC credential VERACODE_API_KEY_SECRET is required}"
: "${VERACODE_APP_NAME:?VERACODE_APP_NAME is required for HMAC SCA scans}"
export VERACODE_API_KEY_ID VERACODE_API_KEY_SECRET VERACODE_APP_NAME
export SRCCLR_REGION="${SRCCLR_REGION:-COM}"
TARGET="$(cd "$TARGET" && pwd)"
PROJECT="$(basename "$TARGET")"
OUT="$ROOT/.github/output/$PROJECT/$(date +%Y-%m-%d_%H%M%S)"
mkdir -p "$OUT"
JSON="$OUT/sca-results.json"
echo "Target      : $TARGET"
echo "Application : $VERACODE_APP_NAME"
echo "Region      : $SRCCLR_REGION"
echo "Output      : $OUT"
if command -v srcclr >/dev/null 2>&1; then
  srcclr test 2>&1 | tee "$OUT/srcclr-test.log"
  srcclr scan "$TARGET" --appname="$VERACODE_APP_NAME" --update-advisor --json="$JSON" 2>&1 | tee "$OUT/sca-console.log"
else
  echo "srcclr not found. Running the official Veracode SCA bootstrap."
  export SCAN_DIR="$TARGET"
  curl -fsSL https://sca-downloads.veracode.com/ci.sh | sh -s -- scan --appname="$VERACODE_APP_NAME" --update-advisor --json="$JSON" 2>&1 | tee "$OUT/sca-console.log"
fi
echo "SCA scan finished. Results: $OUT"

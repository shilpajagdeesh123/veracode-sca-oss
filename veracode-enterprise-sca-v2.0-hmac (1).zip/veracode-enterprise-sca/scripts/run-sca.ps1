param([Parameter(Mandatory=$false)][string]$Target = ".", [string]$AppName = "")
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$EnvFile = Join-Path $Root "config\veracode-sca.env"
if (Test-Path $EnvFile) {
  Get-Content $EnvFile | Where-Object { $_ -and -not $_.Trim().StartsWith('#') } | ForEach-Object {
    $p=$_.Split('=',2); if($p.Count -eq 2 -and $p[1]) { [Environment]::SetEnvironmentVariable($p[0].Trim(),$p[1].Trim(),'Process') }
  }
}
if ($AppName) { $env:VERACODE_APP_NAME=$AppName }
if (-not $env:VERACODE_API_KEY_ID -or -not $env:VERACODE_API_KEY_SECRET) { throw "HMAC credentials missing. Set VERACODE_API_KEY_ID and VERACODE_API_KEY_SECRET." }
if (-not $env:VERACODE_APP_NAME) { throw "VERACODE_APP_NAME is required for HMAC SCA scans." }
if (-not $env:SRCCLR_REGION) { $env:SRCCLR_REGION="COM" }
$Resolved=(Resolve-Path $Target).Path
$Project=Split-Path -Leaf $Resolved
$Stamp=Get-Date -Format "yyyy-MM-dd_HHmmss"
$Out=Join-Path $Root ".github\output\$Project\$Stamp"
New-Item -ItemType Directory -Force -Path $Out | Out-Null
$Json=Join-Path $Out "sca-results.json"
$Log=Join-Path $Out "sca-console.log"
$Args=@('scan',$Resolved,"--appname=$($env:VERACODE_APP_NAME)",'--update-advisor',"--json=$Json")
Write-Host "Target      : $Resolved"
Write-Host "Application : $($env:VERACODE_APP_NAME)"
Write-Host "Region      : $($env:SRCCLR_REGION)"
Write-Host "Output      : $Out"
if (Get-Command srcclr -ErrorAction SilentlyContinue) {
  & srcclr test 2>&1 | Tee-Object -FilePath (Join-Path $Out 'srcclr-test.log')
  & srcclr @Args 2>&1 | Tee-Object -FilePath $Log
  if ($LASTEXITCODE -ne 0) { throw "SCA scan failed with exit code $LASTEXITCODE" }
} else {
  Write-Host "srcclr not found. Running the official Veracode SCA bootstrap."
  $env:SCAN_DIR=$Resolved
  $wc=New-Object System.Net.WebClient
  if($env:HTTPS_PROXY){$wc.Proxy=New-Object System.Net.WebProxy($env:HTTPS_PROXY);$wc.Proxy.Credentials=[System.Net.CredentialCache]::DefaultNetworkCredentials}
  $bootstrap=$wc.DownloadString('https://sca-downloads.veracode.com/ci.ps1')
  $bootArgs=@('scan',"--appname=$($env:VERACODE_APP_NAME)",'--update-advisor',"--json=$Json")
  Invoke-Command -ScriptBlock ([scriptblock]::Create($bootstrap)) -ArgumentList $bootArgs 2>&1 | Tee-Object -FilePath $Log
}
Write-Host "SCA scan finished. Results: $Out"

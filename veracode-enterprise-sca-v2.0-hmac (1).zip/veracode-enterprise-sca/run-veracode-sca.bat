@echo off
setlocal
set "ROOT=%~dp0"
if "%~1"=="" (
  echo Usage: run-veracode-sca.bat ^<project-path^> [Veracode-App-Name]
  exit /b 2
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%ROOT%scripts\run-sca.ps1" -Target "%~1" -AppName "%~2"
exit /b %ERRORLEVEL%

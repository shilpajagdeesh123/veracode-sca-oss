# Veracode Enterprise SCA v2.0 - HMAC

Purpose: run Veracode SCA Agent-Based scans for OSS vulnerabilities, including direct and transitive dependencies, using HMAC credentials and an existing Veracode application profile.

## Required
- Veracode Commercial account with HMAC API credentials
- Existing Veracode application profile eligible for SCA linking
- Internet access to Veracode SCA download/services
- Native build tooling required by the project (for example Java + Maven)

## Configure
Copy `config/veracode-sca.env.example` to `config/veracode-sca.env` and set:

```
VERACODE_API_KEY_ID=<HMAC ID>
VERACODE_API_KEY_SECRET=<HMAC secret>
VERACODE_APP_NAME=<existing application profile name>
SRCCLR_REGION=COM
```

Do not commit `veracode-sca.env`.

You may instead set `VERACODE_API_KEY_ID` and `VERACODE_API_KEY_SECRET` as process environment variables and keep only the app name in the config.

## Windows
```
run-veracode-sca.bat C:\work\customer-service "Customer Service"
```

## Linux/macOS
```
./scripts/run-sca.sh /work/customer-service "Customer Service"
```

## Behavior
1. Validates HMAC ID/secret and application name.
2. Uses local `srcclr` when available.
3. Otherwise invokes Veracode's official SCA bootstrap from `sca-downloads.veracode.com`.
4. Runs an application-profile-linked full scan with `--appname`.
5. Enables Update Advisor.
6. Requests JSON scan output.
7. Stores logs/results under `.github/output/<project>/<timestamp>/`.

## Output
Expected output directory contains `sca-console.log`, `sca-results.json`, and (when local srcclr exists) `srcclr-test.log`.

## Security
Never commit HMAC secrets. `.gitignore` excludes the real config file and output directory.

# Design - HMAC SCA flow

`run-veracode-sca` -> validate HMAC -> validate app profile name -> local srcclr or official bootstrap -> full SCA scan -> dependency graph -> direct/transitive OSS components -> vulnerability analysis -> link results to Veracode application profile -> JSON/log output.

HMAC SCA scans use `--appname` because HMAC authentication is supported for application-profile-based SCA scans. The package intentionally does not use `--quick`, so native build/package-manager analysis can construct dependency information when supported.
